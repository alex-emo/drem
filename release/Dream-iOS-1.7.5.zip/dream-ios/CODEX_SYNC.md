# Codex 同步清单 — Dream iOS 1.7.5

- 基线：Android 1.7.5 / versionCode 28；本包源码与当前 `apps/mobile` 同源。
- iOS MARKETING_VERSION=1.7.5，CURRENT_PROJECT_VERSION=28，Bundle ID `cn.pum.dream`。
- `ios/App/App/public` 已用 `DREAM_API_ORIGIN=https://dream.pum.org.cn` 构建并 `cap sync ios`；`dist/index.html` 与 `ios/App/App/public/index.html` SHA-256 均为 `83c6bc668deee9c994fd44b8ac2560c589497d6f74797e3e43ab27aacdf36810`。
- 本版包含：安卓/iOS 麦克风权限、后台模型温度/身份提示客户端、云备份流式上传/下载（20 MiB 配额，旧接口回退）、错误码 16 进制展示、P0 上下文裁剪与单设备会话。
- 验收：
  1. `bash scripts/build-ios.sh` 模拟器编译通过；
  2. 启动后显示 Dream 登录页；
  3. 登录后发一条消息，确认 SSE 流式、停止按钮、深度思考；
  4. 首次点麦克风应弹 iOS 系统录音授权；
  5. 设置 → 数据管理 → 导出加密备份 / 恢复备份可用；云备份 >20 MiB 应提示超限；
  6. 设置底部版本显示 1.7.5。
- 服务端生产仍为 1.7.3/26；本包已包含 1.7.5 客户端代码，云备份流式接口需服务端升级后完整生效，旧接口会自动回退。
- 已知限制：Linux 环境无法签名/运行 Xcode，本包只做工程与 Web 产物同步；IPA 需在 Mac 上签。
