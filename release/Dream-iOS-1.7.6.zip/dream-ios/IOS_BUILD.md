# Dream iOS 1.7.6 (29) 构建说明

本包是源码同步包，不是签名 IPA。

## 在 Mac 上构建未签名 IPA

```bash
cd dream-ios
npm ci
DREAM_API_ORIGIN=https://dream.pum.org.cn npm run build:web
npx cap sync ios
cd ios/App
xcodebuild -project App.xcodeproj -scheme App -configuration Release -sdk iphoneos \
  -destination 'generic/platform=iOS' -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" DEVELOPMENT_TEAM=""
cd ..
rm -rf Payload Dream-iOS-unsigned.ipa && mkdir Payload
cp -R build/Build/Products/Release-iphoneos/App.app Payload/
zip -qry Dream-iOS-unsigned.ipa Payload
shasum -a 256 Dream-iOS-unsigned.ipa
```

需要安装到真机时，用 Xcode/Sideloadly/AltStore 以你的 Apple ID 重签；未签名 IPA 不能直接安装。

## 版本
- MARKETING_VERSION 1.7.6
- CURRENT_PROJECT_VERSION 29
- 内置 Web 的 API 地址 https://dream.pum.org.cn
