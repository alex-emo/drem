# Dream iOS 1.7.3 构建说明

## A. 模拟器（免签名）
```bash
cd dream-ios
bash scripts/build-ios.sh
open -a Simulator
xcrun simctl install booted build/Build/Products/Debug-iphonesimulator/App.app
xcrun simctl launch booted cn.pum.dream
```

## B. Xcode
```bash
npm install
DREAM_API_ORIGIN=https://dream.pum.org.cn npm run build:web
npx cap sync ios
open ios/App/App.xcodeproj
```
Target `App` → Signing & Capabilities → 选 Team。模拟器 ⌘R。

## C. 真机归档
```bash
TEAM_ID=你的TeamID BUNDLE_ID=cn.pum.dream bash scripts/export-ios.sh
```
或 Xcode Product → Archive；ExportOptions 默认 `development`，可改 ad-hoc/app-store-connect。

## D. 产物
- 模拟器：`build/Build/Products/Debug-iphonesimulator/App.app`
- 归档：`build/Dream.xcarchive`
- IPA：`build/export/`

## E. 常见问题
1. `xcodebuild` 不存在：安装 Xcode 后 `sudo xcode-select -s /Applications/Xcode.app`，并 `sudo xcodebuild -license accept`。
2. SPM 卡住：`xcodebuild -resolvePackageDependencies -project ios/App/App.xcodeproj -scheme App`，Xcode 里 Reset Package Caches。
3. 签名：免费账号真机 7 天；Bundle ID 冲突改 `PRODUCT_BUNDLE_IDENTIFIER` 与 Team。
4. 白屏：先看 `npm run build:web` 是否成功、`ios/App/App/public/index.html` 是否存在；Safari 开发工具看 console。
5. 接口失败：`curl -I https://dream.pum.org.cn/api/v1/health`；自建 http 服务需在 Info.plist 加 ATS 例外。
6. 老设备白屏：确认构建 target 为 `es2017`，`src/lib/compat.ts` 已被最早引入。
