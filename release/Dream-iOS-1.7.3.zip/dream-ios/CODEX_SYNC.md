# Codex 同步清单 — Dream iOS 1.7.3

- 基线：Android 1.7.3 / versionCode 26（commit `6533278`），本包源码与之同源。
- iOS MARKETING_VERSION=1.7.3，CURRENT_PROJECT_VERSION=26，Bundle ID `cn.pum.dream`。
- `ios/App/App/public` 已用 `DREAM_API_ORIGIN=https://dream.pum.org.cn` 构建并 `cap sync ios`。
- 验收：
  1. `bash scripts/build-ios.sh` 模拟器编译通过；
  2. 启动后显示 Dream 登录页；
  3. 登录后发一条消息，确认 SSE 流式、停止按钮、深度思考；
  4. 设置 → 数据管理 → 导出加密备份 / 从导出链接导入可用；
  5. 设置底部版本显示 1.7.3。
- 不需要改服务端；服务端生产为 1.7.3/26，`/api/v1/release` 已上线。
- 已知限制：Linux 环境无法签名/运行 Xcode，本包只做工程与 Web 产物同步；IPA 需在 Mac 上签。
