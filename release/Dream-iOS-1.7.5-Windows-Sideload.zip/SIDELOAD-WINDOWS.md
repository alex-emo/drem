# Dream iOS 1.7.5 — Windows 侧载说明

本包用于在 Windows 10/11 上，把 `Dream-iOS-1.7.5-unsigned.ipa` 侧载到 iPhone。

## 1. 包内容

```
Dream-iOS-1.7.5-unsigned.ipa
Dream-iOS-1.7.5-unsigned.ipa.sha256
SIDELOAD-WINDOWS.md
```

- Bundle ID：`cn.pum.dream`
- 版本：`1.7.5`，build `28`
- 架构：`arm64`（真机，不是模拟器包）
- 最低系统：iOS 15.0
- 状态：**未签名**，不能直接用 iTunes/Filza 安装；必须用 Sideloadly/AltStore 用 Apple ID 重签

SHA-256 校验（PowerShell）：

```powershell
Get-FileHash .\Dream-iOS-1.7.5-unsigned.ipa -Algorithm SHA256
```

期望值：

```
bcf54f305b76241df759e2d37b9eceff2bc123e4b48c8df940bd5d97f5a33615
```

## 2. 前置条件

- Windows 10/11
- iPhone，iOS 15 或更高
- 数据线；iPhone 解锁并点“信任此电脑”
- 一个 Apple ID（免费账号即可；付费开发者账号更稳）
- 安装 **Sideloadly**：https://sideloadly.io/
- Windows 建议安装 **iTunes**（Apple 官网或 Microsoft Store 的“Apple 设备”），用于驱动

## 3. 操作步骤

1. 安装 Sideloadly；Windows 若提示缺少驱动，先装 iTunes/Apple 设备并重启。
2. 连接 iPhone，解锁，点“信任此电脑”。
3. 打开 Sideloadly，确认顶部已识别设备。
4. 把 `Dream-iOS-1.7.5-unsigned.ipa` 拖入 Sideloadly 的 IPA 框。
5. Apple ID 填自己的账号；点 **Start**。
6. 输入 Apple ID 密码；有双重认证时按提示输入验证码。
7. 安装完成后，iPhone 上：
   - 设置 → 通用 → VPN 与设备管理 → 开发者 App → 信任你的 Apple ID
   - iOS 16/17/18：设置 → 隐私与安全性 → 开发者模式 → 打开 → 重启
8. 回到桌面启动 Dream，登录，发一条消息验证流式输出。
9. 设置 → 数据管理 → 确认版本显示 `1.7.5`；点麦克风应弹系统授权。

## 4. 免费 Apple ID 的限制

- 签名 **7 天过期**；到期后 App 打不开，需用 Sideloadly 重新安装（不必卸载）。
- 最多同时 3 个自签 App。
- 每周最多注册 10 个 App ID。
- 换 Apple ID、换电脑、证书吊销后都需要重签。
- 免费账号不能上架 App Store，也不能用 TestFlight。

## 5. 常见问题

**设备检测不到**

- 换数据线/USB 口，优先直连主板后置 USB。
- 安装 iTunes/Apple 设备驱动，重启电脑和 iPhone。
- iPhone 上“信任此电脑”；设置 → 隐私与安全性 → 开发者模式。

**`Unable to install "Dream"` / `A valid provisioning profile ...`**

- Apple ID 或双重认证失败：重登 Apple ID，用 App 专用密码重试。
- 旧证书冲突：Sideloadly 设置里删除旧证书，换一个 Bundle ID，例如 `cn.pum.dream.win` 再装。
- 确认 IPA 没被改坏：重新解压本包，校验 SHA-256。

**`The maximum number of apps for free development profiles has been reached`**

- 删除其他自签 App，或等 7 天过期后重装。

**`Untrusted Developer`**

- 设置 → 通用 → VPN 与设备管理 → 信任对应开发者。

**`Developer Mode` 是灰色**

- 先完成“信任证书”，再重启 iPhone；仍灰则用 Xcode 或重新侧载触发。

**安装后立刻闪退**

- 先确认系统版本 ≥ iOS 15。
- 用 Sideloadly 重新签一次；仍闪退在电脑上看 Sideloadly 日志，并在 iPhone 上取 `设置 → 隐私与安全性 → 分析与改进 → 分析数据` 里最新的 `Dream` 崩溃日志。

**想保留聊天记录**

- 覆盖安装通常保留 WebView 本地数据；仍建议先打开 Dream → 设置 → 数据管理 → 导出加密备份。
- 卸载会清本地记录；云端备份需登录后恢复。

## 6. 备选：AltStore

1. Windows 安装 AltServer（https://altstore.io/）。
2. iPhone 用 AltServer 安装 AltStore。
3. iPhone 打开 AltStore → My Apps → 左上角 + → 选择本包 IPA。
4. 同样需要信任证书、开发者模式、7 天续签。

## 7. 安全说明

- Sideloadly/AltStore 会用你的 Apple ID 向 Apple 申请免费开发证书；Apple ID 密码只在本地工具中使用，不要把密码写进任何仓库文件。
- 建议用 Apple ID 的 **App 专用密码**，不要用主密码。
- 不再使用时，可在 Apple ID 设备管理里移除对应证书。
- 本 IPA 未签名；任何声称“无需签名直接安装”的工具都不要用。
