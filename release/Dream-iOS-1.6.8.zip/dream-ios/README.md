# Dream iOS

Dream 的 iOS 客户端：以官方 MIT 开源 `chat-demo` 的 React UI 为基座，接入 Dream 自建服务端（`https://dream.pum.org.cn`）的登录、会话、SSE 流式聊天、深度思考、联网搜索、文件上传、分享/导出导入等能力。使用 Capacitor 8 + Swift Package Manager，无 CocoaPods。

本包面向 **Mac 上的开发者/Codex**：代码、iOS 工程、构建脚本与说明都在这里，按下面步骤即可编译。

## 1. 环境要求

- macOS 13 Ventura 或更高
- Xcode 16 或更高（含 iOS 15+ SDK）
- Node.js 22 LTS + npm
- 首次打开 Xcode 需要同意许可：`sudo xcodebuild -license accept`
- 真机运行需要 Apple Developer 账号（免费个人账号也可，7 天签名）

检查：

```bash
xcodebuild -version
node -v   # v22.x
npm -v
```

## 2. 最快路径：模拟器一条命令

```bash
cd dream-ios
bash scripts/build-ios.sh
```

脚本会依次执行：

1. `npm ci`（无 lockfile 时 `npm install`）
2. `DREAM_API_ORIGIN=https://dream.pum.org.cn npm run build:web`
3. `npx cap sync ios`（把 `dist/` 同步进 `ios/App/App/public`，并解析 SPM）
4. `xcodebuild` 编译模拟器 Debug 包（免签名）
5. 产物在 `build/Build/Products/Debug-iphonesimulator/App.app`

然后：

```bash
open -a Simulator
xcrun simctl install booted build/Build/Products/Debug-iphonesimulator/App.app
xcrun simctl launch booted cn.pum.dream
```

## 3. 用 Xcode 打开（推荐调试）

```bash
cd dream-ios
npm install
DREAM_API_ORIGIN=https://dream.pum.org.cn npm run build:web
npx cap sync ios
open ios/App/App.xcodeproj
```

在 Xcode：

1. 选择 target `App` → Signing & Capabilities；
2. Team 选择你的 Apple ID，Bundle Identifier 默认 `cn.pum.dream`，如冲突改成自己的；
3. 选择 iPhone 模拟器，⌘R 运行；
4. 真机运行：连接 iPhone，选择设备，首次需在手机“设置 → 通用 → VPN与设备管理”信任开发者。

## 4. 真机归档 / IPA

```bash
TEAM_ID=你的团队ID BUNDLE_ID=cn.pum.dream bash scripts/export-ios.sh
```

或在 Xcode：Product → Archive → Distribute App。导出方式（development / ad-hoc / app-store-connect）取决于你的证书；脚本生成的 `ExportOptions.plist` 默认 `development`。

## 5. 服务端地址

默认 API 源：

```text
https://dream.pum.org.cn
```

构建时覆盖：

```bash
DREAM_API_ORIGIN=http://192.168.1.10:8787 npm run build:web
```

`DREAM_API_ORIGIN` 会编译进 JS，改完必须重新 `build:web` + `cap sync ios`。

## 6. 代码结构

```text
src/
  main.tsx                  React 入口，先加载 lib/compat.ts
  app/App.tsx               登录门禁、会话壳、更新检查（iOS 已禁用 APK 更新提示）
  components/               chat-demo 的 UI（消息、输入框、设置、登录页）
  services/dream/           Dream 适配层
    auth.ts                 登录/注册/token 存储
    api.ts                  Dream SSE → Anthropic 事件流适配；gzip 请求；文件 id/联网搜索
    archive.ts              从导出链接（NDJSON）流式导入
    share.ts                分享链接导入
    update.ts               版本比较（iOS 不弹 Android APK 更新）
    installer.ts            Android APK 安装（iOS 不会调用）
  services/chat/            官方 chat-demo 的会话/分支/Markdown 等逻辑（尽量复用）
ios/App/App.xcodeproj       Xcode 工程（SPM，无 Podfile）
ios/App/CapApp-SPM          Capacitor Swift Package
capacitor.config.ts         appId、webDir、errorPath
scripts/build-ios.sh        模拟器构建
scripts/export-ios.sh       真机归档/导出
public/error.html           页面加载失败兜底页
```

## 7. 功能与验收

启动后：

1. 登录/注册 Dream 账号（服务端开放注册）；
2. 新建对话，确认流式输出、停止生成、编辑提问、消息版本切换；
3. 打开「深度思考」，确认思考过程折叠显示；
4. 打开「联网搜索」，问天气类问题，确认回答带角标与参考来源；
5. 上传一个 `.txt` / `.md` / `.docx`，提问“总结这个文件”；
6. 设置 → 数据管理：分享链接导入、导出链接导入（大 ZIP 走服务端流式解压）；
7. 设置里「阅读宽度」滑块仅桌面 Web 显示，iOS 不显示；
8. iOS 不显示“检查更新/下载 Android APK”。

## 8. 已知限制（iOS）

- iOS 上不提供 App 内 APK 更新（非 App Store 分发，更新检查已禁用）；
- WKWebView 对 `SpeechRecognition` 支持有限，语音输入按钮可能不可用；
- 文件上传只支持纯文本/txt/md/csv/json/代码与 docx 抽取文本；PDF/图片暂不支持；
- Mermaid 暂不渲染（移动端 v1 收起）；
- 聊天记录保存在 WebView IndexedDB；卸载 App 会清除。重装/覆盖安装不会丢。

## 9. 排障

- **SPM 解析失败**：Xcode → File → Packages → Reset Package Caches；或命令行 `xcodebuild -resolvePackageDependencies -project ios/App/App.xcodeproj -scheme App`。
- **签名失败**：确认 Team；不要用别人的 provisioning profile；免费账号真机 7 天有效。
- **白屏**：确认 `npm run build:web` 和 `cap sync ios` 都执行成功；查看 Safari → 开发 → 模拟器/设备 → Dream 的控制台；iOS 无旧 WebView 兼容问题，但 JS 异常会显示兜底错误页。
- **请求失败**：确认服务端 `https://dream.pum.org.cn/api/v1/health` 可访问；自建地址需用 https 或配置 ATS。

## 10. 版本

App 版本 `1.5.1`，iOS build `7`，Bundle ID `cn.pum.dream`。与 Android/服务端版本对齐；修改版本时同步 `package.json`、`ios/App/App.xcodeproj/project.pbxproj` 的 `MARKETING_VERSION/CURRENT_PROJECT_VERSION`、服务端 `DREAM_APP_VERSION`。
