# Dream iOS 编译说明（完整版）

## A. 模拟器（最快，免签名）
```bash
bash scripts/build-ios.sh
open -a Simulator
xcrun simctl install booted build/Build/Products/Debug-iphonesimulator/App.app
xcrun simctl launch booted cn.pum.dream
```

## B. Xcode 运行
```bash
npm install
DREAM_API_ORIGIN=https://dream.pum.org.cn npm run build:web
npx cap sync ios
open ios/App/App.xcodeproj
```
Target `App` → Signing & Capabilities → 选 Team。模拟器 ⌘R；真机连数据线选择设备 ⌘R。

## C. 真机归档
```bash
TEAM_ID=你的TeamID BUNDLE_ID=你自己的BundleID bash scripts/export-ios.sh
```
或 Xcode Product → Archive。`ExportOptions.plist` 中 `method` 可改 `development`、`ad-hoc`、`app-store-connect`。

## D. 构建产物
- 模拟器：`build/Build/Products/Debug-iphonesimulator/App.app`
- 归档：`build/Dream.xcarchive`
- IPA：`build/export/`

## E. 常见问题
1. `xcodebuild -version` 报 command not found：装 Xcode 后 `sudo xcode-select -s /Applications/Xcode.app`。
2. SPM 卡住：`xcodebuild -resolvePackageDependencies -project ios/App/App.xcodeproj -scheme App`，必要时 Xcode 里 Reset Package Caches。
3. 签名：免费账号只能真机 7 天；Bundle ID 冲突就改 `PRODUCT_BUNDLE_IDENTIFIER`。
4. 白屏：看 `npm run build:web` 输出；确认 `ios/App/App/public/index.html` 存在；Safari 开发者工具看 console。
5. 接口失败：`curl -I https://dream.pum.org.cn/api/v1/health`；自建服务需要 https，或在 Info.plist 配 ATS 例外。
