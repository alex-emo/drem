# AGENTS.md — Dream iOS

## 目标
在 macOS 上编译并运行 Dream iOS App（Capacitor 8 + Swift Package Manager），不要重写 UI。这个包已经包含 `dist/` 与 sync 过的 `ios/`，可以先直接打开 Xcode 编译；需要改代码时再走构建流程。

## 一键命令
```bash
bash scripts/build-ios.sh
```
产物：`build/Build/Products/Debug-iphonesimulator/App.app`
安装/启动：
```bash
xcrun simctl install booted build/Build/Products/Debug-iphonesimulator/App.app
xcrun simctl launch booted cn.pum.dream
```

## 修改代码后
```bash
npm install
DREAM_API_ORIGIN=https://dream.pum.org.cn npm run build:web
npx cap sync ios
# 然后在 Xcode 运行，或再执行 scripts/build-ios.sh
```
`DREAM_API_ORIGIN` 会编译进 JS，改地址必须重新 build + sync。

## 关键路径
- `ios/App/App.xcodeproj`：Xcode 工程，scheme `App`，bundle `cn.pum.dream`，iOS 15+
- `ios/App/CapApp-SPM/Package.swift`：Capacitor SPM 依赖，版本 8.6.2
- `src/services/dream/`：Dream 服务端适配（auth/api/share/archive）
- `src/app/App.tsx`：登录门禁、更新弹窗（iOS 已跳过）
- `src/lib/compat.ts`：旧内核 polyfill，入口最先 import
- `capacitor.config.ts`：webDir、errorPath

## 验收标准
1. `xcodebuild ... build` 退出码 0；
2. 模拟器能启动到 Dream 登录页，登录成功后能新建对话；
3. 发一条消息能流式返回；深度思考/联网搜索/文件上传至少各跑一次；
4. 不出现白屏；异常时显示 `public/error.html` 或启动兜底页。

## 约束
- 不要引入 CocoaPods；不要移除 SPM 依赖。
- 不要改 Android 专用逻辑（`installer.ts`、README 的 Android 更新说明）来适配 iOS。
- 不要提交签名证书、Team ID、API Key。
- 若修改版本，必须同时更新：`package.json`、`ios/App/App.xcodeproj/project.pbxproj`（MARKETING_VERSION/CURRENT_PROJECT_VERSION）、服务端 `appVersion`。

## 常见失败
- `xcodebuild: error: Unable to resolve package dependencies` → `xcodebuild -resolvePackageDependencies -project ios/App/App.xcodeproj -scheme App`
- 真机签名失败 → Xcode → Signing & Capabilities 选 Team；或 `TEAM_ID=... BUNDLE_ID=... bash scripts/export-ios.sh`
- `npm ci` 失败 → 没有 lockfile 时用 `npm install`
