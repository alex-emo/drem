# Codex 同步清单 — Dream iOS 1.7.4

- 基线：Android 1.7.4 / versionCode 27（commit `6533278`），本包源码与之同源。
- iOS MARKETING_VERSION=1.7.4，CURRENT_PROJECT_VERSION=27，Bundle ID `cn.pum.dream`。
- `ios/App/App/public` 已用 `DREAM_API_ORIGIN=https://dream.pum.org.cn` 构建并 `cap sync ios`。
- 验收：
  1. `bash scripts/build-ios.sh` 模拟器编译通过；
  2. 启动后显示 Dream 登录页；
  3. 登录后发一条消息，确认 SSE 流式、停止按钮、深度思考；
  4. 设置 → 数据管理 → 导出加密备份 / 从导出链接导入可用；
  5. 设置底部版本显示 1.7.4；
  6. 首次点麦克风应弹 iOS 系统录音授权。
- 服务端生产仍为 1.7.3/26；本包已包含麦克风权限与后台模型设置所需客户端代码，待服务端 1.7.4 部署后完整生效。
- 已知限制：Linux 环境无法签名/运行 Xcode，本包只做工程与 Web 产物同步；IPA 需在 Mac 上签。
