# Dream iOS 1.7.3

Dream 的 iOS 客户端：以官方 MIT 开源 `chat-demo` 的 React UI 为基座，接入 Dream 自建服务端 `https://dream.pum.org.cn`，与 Android 1.7.3 共用同一套移动端源码。

本包面向 **Mac 上的开发者 / Codex**：包含完整 iOS 工程、Web 源码、已同步的 `ios/App/App/public` 构建产物、构建脚本与说明，按下面步骤即可编译。

## 版本

- 应用版本：1.7.3
- iOS build：26
- Bundle ID：`cn.pum.dream`
- 服务端：`https://dream.pum.org.cn`（`/api/v1`）
- 最低 iOS：15.0
- Capacitor 8 + Swift Package Manager，无需 CocoaPods

## 与 Android 1.7.3 同步的能力

- Dream 账号登录/注册/退出、Bearer token
- SSE 流式聊天、深度思考、停止生成、错误/内容拒绝
- 联网搜索与来源引用、文件上传/跨轮附件继承
- 会话树/分支切换、编辑消息、重新生成
- 本地 IndexedDB 会话；AES-GCM 加密云备份、删除墓碑同步、6MB 自动上传保护
- 1.7.3 上下文压缩/裁剪重试；Web 流式 `stopped` 状态
- 公告弹窗、`/api/v1/release` 更新检查（iOS 跳过 APK 安装）
- iOS 启动兜底页、ES2017 兼容层（老设备白屏防护）

## 快速构建（模拟器）

```bash
cd dream-ios
bash scripts/build-ios.sh
open -a Simulator
xcrun simctl install booted build/Build/Products/Debug-iphonesimulator/App.app
xcrun simctl launch booted cn.pum.dream
```

脚本执行：`npm ci`（无 lockfile 则 `npm install`）→ `DREAM_API_ORIGIN=https://dream.pum.org.cn npm run build:web` → `npx cap sync ios` → `xcodebuild` 模拟器 Debug。

## Xcode 运行

```bash
npm install
DREAM_API_ORIGIN=https://dream.pum.org.cn npm run build:web
npx cap sync ios
open ios/App/App.xcodeproj
```

Target `App` → Signing & Capabilities → 选择 Team；模拟器 ⌘R。真机首次需在“设置 → 通用 → VPN与设备管理”信任开发者。

## 真机归档 / IPA

```bash
TEAM_ID=你的团队ID BUNDLE_ID=cn.pum.dream bash scripts/export-ios.sh
```

或 Xcode Product → Archive。产物在 `build/export/`；签名方式取决于证书。

## 目录

- `src/`：React 源码（Dream 登录、SSE、会话、设置、公告等）
- `ios/`：Capacitor iOS 工程（`App.xcodeproj`、SPM、`App/public`）
- `dist/`：已构建 Web 产物（API 指向生产）
- `scripts/build-ios.sh`、`scripts/export-ios.sh`
- `BUILDING_IOS.md`：完整构建/排错说明
- `CODEX_SYNC.md`：本次同步的验收清单

## 环境

- macOS 13+
- Xcode 16+
- Node.js 22 LTS + npm
